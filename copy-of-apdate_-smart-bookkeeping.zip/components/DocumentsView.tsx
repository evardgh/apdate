
import React, { useState } from 'react';
import { Transaction, Quotation, Client } from '../types';
import { PlusIcon } from './icons/PlusIcon';
import { DocumentTextIcon } from './icons/DocumentTextIcon';
import { useAppContext } from '../context/AppContext';
import StatusBadge from './StatusBadge';
import { MicrophoneIcon } from './icons/MicrophoneIcon';

interface InvoicesAndQuotesViewProps {
  onPreviewInvoice: (invoice: Transaction) => void;
  onPreviewQuote: (quote: Quotation) => void;
  onCreateInvoice: () => void;
  onCreateQuote: () => void;
  onVoiceInvoiceClick: () => void;
  onVoiceQuoteClick: () => void;
}

const SegmentedControl: React.FC<{
    options: { value: string; label: string; }[];
    value: string;
    onChange: (value: string) => void;
}> = ({ options, value, onChange }) => (
    <div className="flex w-full rounded-xl bg-light-bg-inset dark:bg-dark-bg-inset p-1 mb-4">
        {options.map(opt => (
            <button
                key={opt.value}
                type="button"
                onClick={() => onChange(opt.value)}
                className={`w-full p-2.5 rounded-lg font-semibold transition-all duration-300 text-sm focus:outline-none
                    ${value === opt.value
                        ? 'bg-light-bg-subtle dark:bg-dark-bg-subtle text-light-fg-default dark:text-dark-fg-default shadow'
                        : 'text-light-fg-subtle dark:text-dark-fg-subtle hover:text-light-fg-default dark:hover:text-dark-fg-default'}`
                }
            >
                {opt.label}
            </button>
        ))}
    </div>
);

const DocListItem: React.FC<{
    doc: Transaction | Quotation,
    clientName: string,
    currency: string,
    onClick: () => void
}> = ({ doc, clientName, currency, onClick }) => {
    const isQuote = 'quotationNumber' in doc;
    const amount = isQuote ? doc.total : doc.amount;
    const status = isQuote ? doc.status : doc.status;
    const number = isQuote ? doc.quotationNumber : doc.transactionNumber;

    return (
        <li onClick={onClick} className="p-4 bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl cursor-pointer hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors">
            <div className="flex items-start justify-between">
                <div className="truncate pr-4">
                    <p className="font-semibold text-light-fg-default dark:text-dark-fg-default truncate">{clientName}</p>
                    <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">
                        {new Date(doc.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                        {' • '}
                        {number}
                    </p>
                </div>
                <div className="flex flex-col items-end flex-shrink-0 ml-2">
                    <p className="font-semibold text-light-fg-default dark:text-dark-fg-default">
                        {currency} {amount.toLocaleString()}
                    </p>
                    <div className="mt-1">
                        <StatusBadge status={status} />
                    </div>
                </div>
            </div>
        </li>
    );
};


const InvoicesAndQuotesView: React.FC<InvoicesAndQuotesViewProps> = ({ 
    onPreviewInvoice, onPreviewQuote, onCreateInvoice, onCreateQuote, onVoiceInvoiceClick, onVoiceQuoteClick
}) => {
    const { activeBusiness, dataForActiveBusiness } = useAppContext();
    const [tab, setTab] = useState<'invoices' | 'quotes'>('invoices');

    const invoices = dataForActiveBusiness.visibleTransactions.filter(t => t.type === 'income' && t.transactionNumber.startsWith('INV-'));
    const quotes = dataForActiveBusiness.quotations;
    const clients = dataForActiveBusiness.clients;
    const currency = activeBusiness?.currency || '';
    
    const getClientName = (clientId: string) => clients.find(c => c.id === clientId)?.name || 'N/A';

    const renderContent = () => {
        const listData = tab === 'invoices' ? invoices : quotes;
        const onPreview = tab === 'invoices' ? onPreviewInvoice : onPreviewQuote;

        if(listData.length === 0) {
            return (
                <div className="text-center text-light-fg-subtle dark:text-dark-fg-subtle mt-10 flex flex-col items-center">
                    <DocumentTextIcon className="w-12 h-12 mb-4 text-light-fg-subtle/50 dark:text-dark-fg-subtle/50" />
                    <h3 className="text-lg font-semibold text-light-fg-default dark:text-dark-fg-default">No {tab} yet</h3>
                    <p>Get started by creating your first {tab === 'invoices' ? 'invoice' : 'quote'}.</p>
                </div>
            )
        }

        return (
            <ul className="space-y-3">
                {listData.map(doc => (
                    <DocListItem 
                        key={doc.id}
                        doc={doc}
                        clientName={getClientName(doc.clientId!)}
                        currency={currency}
                        onClick={() => onPreview(doc as any)}
                    />
                ))}
            </ul>
        )
    };
    
    const handleAddClick = () => {
        if(tab === 'invoices') onCreateInvoice();
        else onCreateQuote();
    }
    
    const handleVoiceAddClick = () => {
        if(tab === 'invoices') onVoiceInvoiceClick();
        else onVoiceQuoteClick();
    }

    return (
        <div className="space-y-4">
            <SegmentedControl 
                value={tab}
                onChange={(val) => setTab(val as any)}
                options={[
                    { value: 'invoices', label: 'Invoices' },
                    { value: 'quotes', label: 'Quotes' }
                ]}
            />

            <div className="flex items-center gap-2">
                <button 
                    onClick={handleAddClick}
                    className="flex-1 flex items-center justify-center gap-2 bg-accent text-accent-fg font-bold py-3 px-4 rounded-xl hover:opacity-90 transition-opacity"
                >
                    <PlusIcon className="w-6 h-6" />
                    Create {tab === 'invoices' ? 'Invoice' : 'Quote'}
                </button>
                 <button 
                    onClick={handleVoiceAddClick}
                    className="w-12 h-12 flex-shrink-0 flex items-center justify-center bg-accent text-accent-fg font-bold rounded-xl hover:opacity-90 transition-opacity"
                    aria-label={`Create ${tab} with Voice`}
                >
                    <MicrophoneIcon />
                </button>
            </div>

            {renderContent()}
        </div>
    );
};

export default InvoicesAndQuotesView;
