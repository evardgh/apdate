
import React, { createContext, useContext, useState, useMemo, useCallback, ReactNode, useEffect } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { getInitialData } from '../services/initialData';
import { 
    AppData, Transaction, Business, Category, TransactionType, Client, Vendor, Item, Quotation, QuotationItem, Payment, PartialTransaction, ExpenseType 
} from '../types';

interface ConfirmationState {
    isOpen: boolean;
    title: string;
    message: React.ReactNode;
    onConfirm: () => void;
}

interface AppContextType {
    appData: AppData;
    setAppData: React.Dispatch<React.SetStateAction<AppData>>;
    activeBusinessId: string | null;
    setActiveBusinessId: React.Dispatch<React.SetStateAction<string | null>>;
    activeBusiness: Business | null;
    dataForActiveBusiness: {
        visibleTransactions: Transaction[];
        quotations: Quotation[];
        clients: Client[];
        vendors: Vendor[];
        items: Item[];
    };
    usedClientIds: Set<string>;
    usedVendorIds: Set<string>;
    addTransaction: (transaction: Omit<Transaction, 'id' | 'businessId' | 'transactionNumber' | 'status' | 'payments'>, isBill?: boolean) => void;
    updateTransaction: (transaction: Transaction) => void;
    deleteTransaction: (id: string) => void;
    addPayment: (transactionId: string, payment: Omit<Payment, 'id'>) => void;
    addQuotation: (quotationData: Omit<Quotation, 'id' | 'businessId' | 'quotationNumber'>) => void;
    updateQuotation: (quotation: Quotation) => void;
    deleteQuotation: (id: string) => void;
    convertQuoteToInvoice: (quote: Quotation) => void;
    createInvoiceFromScratch: (quoteData: Omit<Quotation, 'businessId' | 'quotationNumber'>) => void;
    addCategory: (name: string, type: TransactionType, expenseType?: 'Operating Expenses' | 'Cost of Goods Sold' | 'Other Expenses' | 'Non-Operating Expenses') => void;
    addItem: (itemData: Omit<Item, 'id'>) => Item;
    addClient: (clientData: Omit<Client, 'id'>) => Client;
    updateClient: (client: Client) => void;
    deleteClient: (id: string, isUsed: boolean) => void;
    addVendor: (vendorData: Omit<Vendor, 'id'>) => Vendor;
    updateVendor: (vendor: Vendor) => void;
    deleteVendor: (id: string, isUsed: boolean) => void;
    addBusiness: (businessData: Omit<Business, 'id'>) => void;
    updateBusiness: (business: Business) => void;
    onOnboardingComplete: (businessName: string, currency: string, openingBalance: number) => void;
    confirmationState: ConfirmationState;
    askForConfirmation: (title: string, message: React.ReactNode, onConfirm: () => void) => void;
    closeConfirmation: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [appData, setAppData] = useLocalStorage<AppData>('appData', getInitialData());
    
    const [activeBusinessIdState, setActiveBusinessIdState] = useLocalStorage<{ value: string | null }>(
        'activeBusinessId',
        { value: null }
    );
    const activeBusinessId = useMemo(() => activeBusinessIdState.value, [activeBusinessIdState]);

    const setActiveBusinessId: React.Dispatch<React.SetStateAction<string | null>> = useCallback((valueOrUpdater) => {
        setActiveBusinessIdState(prevState => {
            const oldId = prevState.value;
            const newId = typeof valueOrUpdater === 'function'
                ? (valueOrUpdater as (prevState: string | null) => string | null)(oldId)
                : valueOrUpdater;
            return { value: newId };
        });
    }, [setActiveBusinessIdState]);
    
    useEffect(() => {
        const businessExists = activeBusinessId && appData.businesses.some(b => b.id === activeBusinessId);
        
        if (!businessExists && appData.businesses.length > 0) {
            // If current ID is invalid or null, set to the first available business
            setActiveBusinessId(appData.businesses[0].id);
        } else if (appData.businesses.length === 0) {
            // If there are no businesses, ensure ID is null
            setActiveBusinessId(null);
        }
    }, [appData.businesses, activeBusinessId, setActiveBusinessId]);

    const [confirmationState, setConfirmationState] = useState<ConfirmationState>({
        isOpen: false,
        title: '',
        message: '',
        onConfirm: () => {},
    });

    const askForConfirmation = (title: string, message: React.ReactNode, onConfirm: () => void) => {
        setConfirmationState({ isOpen: true, title, message, onConfirm });
    };

    const closeConfirmation = useCallback(() => {
        setConfirmationState(prev => ({ ...prev, isOpen: false }));
    }, []);

    const addBusiness = (businessData: Omit<Business, 'id'>) => {
        const newBusiness: Business = {
            ...businessData,
            id: `biz-${Date.now()}`,
        };
        setAppData(prev => ({
            ...prev,
            businesses: [...prev.businesses, newBusiness]
        }));
        if(!activeBusinessId) {
            setActiveBusinessId(newBusiness.id);
        }
    };

    const updateBusiness = (updatedBusiness: Business) => {
        setAppData(prev => ({
            ...prev,
            businesses: prev.businesses.map(b => b.id === updatedBusiness.id ? updatedBusiness : b)
        }));
    };
    
    const onOnboardingComplete = (businessName: string, currency: string, openingBalance: number) => {
        const newBusiness: Business = {
            id: `biz-${Date.now()}`,
            name: businessName,
            currency: currency,
            taxRate: 0,
            paymentTerms: 30,
            invoiceNotes: 'Thank you for your business!'
        };

        const newTransactions: Transaction[] = [];
        if (openingBalance > 0) {
            newTransactions.push({
                id: `txn-${Date.now()}`,
                businessId: newBusiness.id,
                type: 'income',
                name: "Owner's Equity",
                description: "Initial opening balance.",
                amount: openingBalance,
                date: new Date().toISOString(),
                category: "Owner's Equity",
                transactionNumber: 'EQUITY-001',
                nature: 'service',
                status: 'paid',
                payments: []
            });
        }
        
        setAppData(prev => ({
            ...prev,
            businesses: [newBusiness],
            transactions: [...prev.transactions, ...newTransactions],
        }));

        setActiveBusinessId(newBusiness.id);
        localStorage.setItem('hasCompletedOnboarding', 'true');
    };
    
    const addTransaction = (transactionData: Omit<Transaction, 'id' | 'businessId' | 'transactionNumber' | 'status' | 'payments'>, isBill: boolean = false) => {
        if (!activeBusinessId) return;

        const incomeCount = appData.transactions.filter(t => t.businessId === activeBusinessId && t.type === 'income' && t.transactionNumber.startsWith('INV-')).length;
        const expenseCount = appData.transactions.filter(t => t.businessId === activeBusinessId && t.type === 'expense').length;

        const newTransaction: Transaction = {
            id: `txn-${Date.now()}`,
            businessId: activeBusinessId,
            transactionNumber: transactionData.type === 'income' 
                ? `INV-${String(incomeCount + 1).padStart(3, '0')}`
                : `EXP-${String(expenseCount + 1).padStart(3, '0')}`,
            ...transactionData,
            status: isBill ? 'unpaid' : 'paid',
            payments: isBill ? [] : [{ id: `p-${Date.now()}`, date: transactionData.date, amount: transactionData.amount, method: 'cash' }]
        };

        if (transactionData.orderStatus) {
            newTransaction.status = 'unpaid';
            newTransaction.payments = [];
        }
        
        setAppData(prev => ({ ...prev, transactions: [...prev.transactions, newTransaction] }));
    };

    const updateTransaction = (updatedTransaction: Transaction) => {
        setAppData(prev => ({
            ...prev,
            transactions: prev.transactions.map(t => t.id === updatedTransaction.id ? updatedTransaction : t)
        }));
    };

    const deleteTransaction = (id: string) => {
        askForConfirmation('Void Transaction?', 'This will mark the transaction as voided. This action cannot be undone.', () => {
            setAppData(prev => ({
                ...prev,
                transactions: prev.transactions.map(t => t.id === id ? { ...t, status: 'voided' } : t)
            }));
        });
    };
    
    const addPayment = (transactionId: string, payment: Omit<Payment, 'id'>) => {
        setAppData(prev => {
            const newTransactions = prev.transactions.map(t => {
                if (t.id === transactionId) {
                    const newPayments = [...t.payments, { ...payment, id: `p-${Date.now()}` }];
                    const totalPaid = newPayments.reduce((sum, p) => sum + p.amount, 0);
                    let newStatus: Transaction['status'] = 'partially_paid';
                    if (totalPaid >= t.amount) {
                        newStatus = 'paid';
                    }
                    return { ...t, payments: newPayments, status: newStatus };
                }
                return t;
            });
            return { ...prev, transactions: newTransactions };
        });
    };

    const addQuotation = (quotationData: Omit<Quotation, 'id' | 'businessId' | 'quotationNumber'>) => {
        if (!activeBusinessId) return;
        const quoteCount = appData.quotations.filter(q => q.businessId === activeBusinessId).length;
        const newQuotation: Quotation = {
            ...quotationData,
            id: `qt-${Date.now()}`,
            businessId: activeBusinessId,
            quotationNumber: `QT-${String(quoteCount + 1).padStart(3, '0')}`,
        };
        setAppData(prev => ({ ...prev, quotations: [...prev.quotations, newQuotation] }));
    };

    const updateQuotation = (updatedQuotation: Quotation) => {
        setAppData(prev => ({
            ...prev,
            quotations: prev.quotations.map(q => q.id === updatedQuotation.id ? updatedQuotation : q)
        }));
    };
    
    const deleteQuotation = (id: string) => {
        askForConfirmation('Delete Quotation?', 'Are you sure you want to permanently delete this quotation?', () => {
             setAppData(prev => ({
                ...prev,
                quotations: prev.quotations.filter(q => q.id !== id)
            }));
        });
    };

    const convertQuoteToInvoice = (quote: Quotation) => {
        if (!activeBusinessId) return;
        const currentBusiness = appData.businesses.find(b => b.id === activeBusinessId);
        const incomeCount = appData.transactions.filter(t => t.businessId === activeBusinessId && t.type === 'income' && t.transactionNumber.startsWith('INV-')).length;
        
        const invoiceFromQuote: Transaction = {
            id: `txn-${Date.now()}`,
            businessId: activeBusinessId,
            type: 'income',
            name: `Invoice from ${quote.quotationNumber}`,
            description: `Based on quotation ${quote.quotationNumber}.`,
            amount: quote.total,
            date: new Date().toISOString(),
            dueDate: new Date(new Date().setDate(new Date().getDate() + (currentBusiness?.paymentTerms || 15))).toISOString(),
            category: 'Service Revenue', 
            clientId: quote.clientId,
            transactionNumber: `INV-${String(incomeCount + 1).padStart(3, '0')}`,
            nature: 'service', 
            relatedQuotationId: quote.id,
            status: 'unpaid',
            payments: [],
        };

        setAppData(prev => ({
            ...prev,
            transactions: [...prev.transactions, invoiceFromQuote],
            quotations: prev.quotations.map(q => q.id === quote.id ? { ...q, status: 'accepted' } : q),
        }));
    };

    const createInvoiceFromScratch = (quoteData: Omit<Quotation, 'businessId' | 'quotationNumber'>) => {
       if (!activeBusinessId) return;
        const incomeCount = appData.transactions.filter(t => t.businessId === activeBusinessId && t.type === 'income' && t.transactionNumber.startsWith('INV-')).length;
        const newInvoice: Transaction = {
            id: `txn-${Date.now()}`,
            businessId: activeBusinessId,
            type: 'income',
            name: quoteData.items.map((i: QuotationItem) => i.name).join(', '),
            description: quoteData.notes || '',
            amount: quoteData.total,
            date: quoteData.date,
            dueDate: quoteData.expiryDate,
            category: 'Service Revenue',
            clientId: quoteData.clientId,
            transactionNumber: `INV-${String(incomeCount + 1).padStart(3, '0')}`,
            nature: 'service',
            status: 'unpaid',
            payments: [],
        };
         setAppData(prev => ({ ...prev, transactions: [...prev.transactions, newInvoice]}));
    };
    
    const addCategory = (name: string, type: TransactionType, expenseType?: ExpenseType) => {
        const newCategory: Category = { id: `cat-${Date.now()}`, name, type, expenseType };
        setAppData(prev => ({ ...prev, categories: [...prev.categories, newCategory] }));
    };

    const addItem = (itemData: Omit<Item, 'id'>): Item => {
        const newItem: Item = { ...itemData, id: `item-${Date.now()}` };
        setAppData(prev => ({ ...prev, items: [...prev.items, newItem] }));
        return newItem;
    };
    
    const addClient = (clientData: Omit<Client, 'id'>): Client => {
        const newClient: Client = { ...clientData, id: `client-${Date.now()}` };
        setAppData(prev => ({ ...prev, clients: [...prev.clients, newClient] }));
        return newClient;
    };

    const updateClient = (updatedClient: Client) => {
        setAppData(prev => ({
            ...prev,
            clients: prev.clients.map(c => c.id === updatedClient.id ? updatedClient : c)
        }));
    };

    const deleteClient = (id: string, isUsed: boolean) => {
        const message = isUsed 
            ? "This client is linked to some transactions. Deleting them might affect your reports. Are you sure?"
            : "Are you sure you want to delete this client?";
        askForConfirmation('Delete Client?', message, () => {
            setAppData(prev => ({ ...prev, clients: prev.clients.filter(c => c.id !== id) }));
        });
    };
    
    const addVendor = (vendorData: Omit<Vendor, 'id'>): Vendor => {
        const newVendor: Vendor = { ...vendorData, id: `vendor-${Date.now()}` };
        setAppData(prev => ({ ...prev, vendors: [...prev.vendors, newVendor] }));
        return newVendor;
    };
    
    const updateVendor = (updatedVendor: Vendor) => {
        setAppData(prev => ({
            ...prev,
            vendors: prev.vendors.map(v => v.id === updatedVendor.id ? updatedVendor : v)
        }));
    };
    
    const deleteVendor = (id: string, isUsed: boolean) => {
        const message = isUsed
            ? "This vendor is linked to some transactions. Deleting them might affect your reports. Are you sure?"
            : "Are you sure you want to delete this vendor?";
        askForConfirmation('Delete Vendor?', message, () => {
            setAppData(prev => ({ ...prev, vendors: prev.vendors.filter(v => v.id !== id) }));
        });
    };
    
    const activeBusiness = useMemo(() => {
        return appData.businesses.find(b => b.id === activeBusinessId) || null;
    }, [appData.businesses, activeBusinessId]);

    const dataForActiveBusiness = useMemo(() => {
        if (!activeBusinessId) {
            return { visibleTransactions: [], quotations: [], clients: [], vendors: [], items: [] };
        }
        const transactions = appData.transactions.filter(t => t.businessId === activeBusinessId && t.status !== 'voided');
        const quotations = appData.quotations.filter(q => q.businessId === activeBusinessId);
        return {
            visibleTransactions: transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
            quotations: quotations.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
            clients: appData.clients,
            vendors: appData.vendors,
            items: appData.items,
        };
    }, [activeBusinessId, appData]);

    const usedClientIds = useMemo(() => new Set(appData.transactions.map(t => t.clientId)), [appData.transactions]);
    const usedVendorIds = useMemo(() => new Set(appData.transactions.map(t => t.vendorId)), [appData.transactions]);
    
    const contextValue: AppContextType = {
        appData,
        setAppData,
        activeBusinessId,
        setActiveBusinessId,
        activeBusiness,
        dataForActiveBusiness,
        usedClientIds,
        usedVendorIds,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        addPayment,
        addQuotation,
        updateQuotation,
        deleteQuotation,
        convertQuoteToInvoice,
        createInvoiceFromScratch,
        addCategory,
        addItem,
        addClient,
        updateClient,
        deleteClient,
        addVendor,
        updateVendor,
        deleteVendor,
        addBusiness,
        updateBusiness,
        onOnboardingComplete,
        confirmationState,
        askForConfirmation,
        closeConfirmation,
    };

    return (
        <AppContext.Provider value={contextValue}>
            {children}
        </AppContext.Provider>
    );
};

export const useAppContext = () => {
    const context = useContext(AppContext);
    if (context === undefined) {
        throw new Error('useAppContext must be used within an AppProvider');
    }
    return context;
};
