
import { useState, useEffect } from 'react';

function useLocalStorage<T extends object>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] {
  const [storedValue, setStoredValue] = useState<T>(() => {
    if (typeof window === 'undefined') {
      return initialValue;
    }
    try {
      const item = window.localStorage.getItem(key);
      const loadedValue = item ? JSON.parse(item) : initialValue;

      // Create a validated state object, starting with the defaults.
      // This ensures that if the stored data is from an older version of the app
      // or corrupted, it won't crash the app.
      const validatedState = { ...initialValue };

      for (const k in initialValue) {
        const keyOfT = k as keyof T;
        
        // Check if the loaded data has this property and it's not null/undefined
        if (loadedValue && Object.prototype.hasOwnProperty.call(loadedValue, keyOfT) && loadedValue[keyOfT] !== null && loadedValue[keyOfT] !== undefined) {
            const initialField = initialValue[keyOfT];
            const loadedField = loadedValue[keyOfT];

            // If initial value is an array, ensure loaded value is also an array before using it.
            if (Array.isArray(initialField)) {
                if (Array.isArray(loadedField)) {
                    (validatedState as any)[keyOfT] = loadedField;
                }
            // If initial value is an object (like settings), deep merge it to be safe.
            } else if (typeof initialField === 'object' && initialField !== null) {
                if (typeof loadedField === 'object' && loadedField !== null) {
                    (validatedState as any)[keyOfT] = { ...initialField, ...loadedField };
                }
            // For other primitive types, just assign.
            } else {
                (validatedState as any)[keyOfT] = loadedField;
            }
        }
      }

      return validatedState;

    } catch (error) {
      console.error(`Error parsing localStorage key "${key}", falling back to initial data.`, error);
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(storedValue));
    } catch (error) {
      console.error(`Error saving to localStorage for key "${key}":`, error);
    }
  }, [key, storedValue]);

  return [storedValue, setStoredValue];
}

export default useLocalStorage;
