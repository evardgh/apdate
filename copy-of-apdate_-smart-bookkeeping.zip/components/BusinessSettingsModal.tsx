import React, { useState, useEffect } from 'react';
import { Business } from '../types';
import { CloseIcon } from './icons/CloseIcon';
import { AppIcon } from './icons/AppIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';

interface BusinessSettingsModalProps {
  businessToEdit?: Business | null;
  initialData?: Partial<Business>;
  onSave: (businessData: Omit<Business, 'id'> & { id?: string }) => void;
  onClose: () => void;
}

const BusinessSettingsModal: React.FC<BusinessSettingsModalProps> = ({ businessToEdit, initialData, onSave, onClose }) => {
  const isEditMode = !!businessToEdit;

  const [name, setName] = useState('');
  const [logo, setLogo] = useState<string | undefined>(undefined);
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [website, setWebsite] = useState('');
  const [currency, setCurrency] = useState('GH₵');
  const [taxRate, setTaxRate] = useState<number | string>('');
  const [paymentTerms, setPaymentTerms] = useState<number | string>(30);
  const [invoiceNotes, setInvoiceNotes] = useState('Thank you for your business!');
  const [logoUploadSuccess, setLogoUploadSuccess] = useState(false);

  useEffect(() => {
    const data = businessToEdit || initialData;
    if (data) {
        setName(data.name || '');
        setLogo(data.logo || undefined);
        setPhone(data.phone || '');
        setEmail(data.email || '');
        setAddress(data.address || '');
        setWebsite(data.website || '');
        setCurrency(data.currency || 'GH₵');
        setTaxRate(data.taxRate ?? '');
        setPaymentTerms(data.paymentTerms ?? '');
        setInvoiceNotes(data.invoiceNotes || '');
    }
  }, [businessToEdit, initialData]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) { // 2MB size limit
        alert("Logo size should be less than 2MB.");
        return;
    }
    const reader = new FileReader();
    reader.onloadend = () => {
      setLogo(reader.result as string);
      setLogoUploadSuccess(true);
      setTimeout(() => setLogoUploadSuccess(false), 3000);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Please enter a business name');
      return;
    }
    
    const payload: Omit<Business, 'id'> & { id?: string } = {
        name,
        logo,
        phone,
        email,
        address,
        website,
        currency,
        taxRate: Number(taxRate) || 0,
        paymentTerms: Number(paymentTerms) || 0,
        invoiceNotes,
    };

    if (isEditMode) {
      payload.id = businessToEdit.id;
    }
    onSave(payload);
    onClose();
  };

  const commonInputClasses = "w-full bg-light-bg-inset dark:bg-dark-bg-inset border-transparent focus:border-accent border-2 rounded-xl py-3 px-4 focus:outline-none focus:ring-0 text-light-fg-default dark:text-dark-fg-default placeholder:text-light-fg-subtle placeholder:dark:text-dark-fg-subtle transition-colors";
  const commonLabelClasses = "block text-sm font-medium mb-1.5 text-light-fg-subtle dark:text-dark-fg-subtle";

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in" onClick={onClose}>
        <div 
            className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl shadow-2xl w-full max-w-md m-4 p-6 relative animate-slide-up border border-light-border-default/50 dark:border-dark-border-default max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
        >
            <div className="flex justify-between items-center mb-6 flex-shrink-0">
                <h2 className="text-xl font-bold text-light-fg-default dark:text-dark-fg-default">
                    {isEditMode ? 'Edit Business' : 'Add New Business'}
                </h2>
                <button onClick={onClose} className="text-light-fg-subtle dark:text-dark-fg-subtle hover:text-light-fg-default dark:hover:text-dark-fg-default">
                    <CloseIcon />
                </button>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-4 overflow-y-auto pr-2 flex-grow">
                <div className="flex items-center gap-4">
                    <div className="w-20 h-20 rounded-full bg-light-bg-inset dark:bg-dark-bg-inset flex items-center justify-center overflow-hidden flex-shrink-0">
                        {logo ? <img src={logo} alt="Business Logo" className="w-full h-full object-cover" /> : <AppIcon className="w-12 h-12 opacity-50"/>}
                    </div>
                    <div className="flex-1">
                        <label htmlFor="logo-upload" className={commonLabelClasses}>Business Logo</label>
                        <input id="logo-upload" type="file" accept="image/png, image/jpeg" onChange={handleFileChange} className="text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-accent/10 file:text-accent hover:file:bg-accent/20"/>
                    </div>
                </div>

                {logoUploadSuccess && (
                    <div className="flex items-center gap-2 text-sm text-green-700 bg-green-100 dark:bg-green-900 dark:text-green-300 p-2 rounded-lg">
                        <CheckCircleIcon className="w-5 h-5"/>
                        <span>Logo uploaded successfully!</span>
                    </div>
                )}
            
                <input
                    name="name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Business Name"
                    className={commonInputClasses}
                    required
                />
                 <input
                    name="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Contact Email (Optional)"
                    className={commonInputClasses}
                />
                <input
                    name="phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Phone Number (Optional)"
                    className={commonInputClasses}
                />
                <input
                    name="address"
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Address (Optional)"
                    className={commonInputClasses}
                />
                 <input
                    name="website"
                    type="url"
                    value={website}
                    onChange={(e) => setWebsite(e.target.value)}
                    placeholder="Website (Optional)"
                    className={commonInputClasses}
                />

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className={commonLabelClasses}>Currency</label>
                        <select
                            name="currency"
                            value={currency}
                            onChange={(e) => setCurrency(e.target.value)}
                            className={commonInputClasses}
                        >
                            <option value="GH₵">GH₵ - Ghanaian Cedi</option>
                            <option value="$">USD - US Dollar</option>
                            <option value="€">EUR - Euro</option>
                            <option value="£">GBP - British Pound</option>
                        </select>
                    </div>
                    <div>
                        <label className={commonLabelClasses}>Default Tax Rate (%)</label>
                        <input
                            name="taxRate"
                            type="number"
                            value={taxRate}
                            onChange={(e) => setTaxRate(e.target.value)}
                            placeholder="e.g. 15"
                            className={commonInputClasses}
                            step="0.01"
                        />
                    </div>
                </div>
                
                <div>
                    <label className={commonLabelClasses}>Default Payment Terms (Days)</label>
                    <input
                        name="paymentTerms"
                        type="number"
                        value={paymentTerms}
                        onChange={(e) => setPaymentTerms(e.target.value)}
                        placeholder="e.g. 30"
                        className={commonInputClasses}
                    />
                </div>

                <div>
                    <label className={commonLabelClasses}>Default Invoice Notes</label>
                    <textarea
                        name="invoiceNotes"
                        value={invoiceNotes}
                        onChange={(e) => setInvoiceNotes(e.target.value)}
                        rows={3}
                        placeholder="e.g. Thank you for your business!"
                        className={commonInputClasses}
                    />
                </div>

                <div className="pt-2 flex-shrink-0">
                  <button type="submit" className="w-full bg-accent text-accent-fg font-bold py-3.5 px-4 rounded-xl hover:opacity-90 transition-opacity">
                      {isEditMode ? 'Save Changes' : 'Add Business'}
                  </button>
                </div>
            </form>
        </div>
    </div>
  );
};

export default BusinessSettingsModal;