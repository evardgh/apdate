
import React, { useState, useMemo, useEffect } from 'react';
import { Transaction, TransactionType, Category, Client, Vendor, expenseTypes, ExpenseType, Item, PartialTransaction } from '../types';
import { CloseIcon } from './icons/CloseIcon';
import AddClientModal from './AddClientModal';
import AddVendorModal from './AddVendorModal';
import { recommendExpenseType } from '../services/geminiService';
import { SparklesIcon } from './icons/SparklesIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { useAppContext } from '../context/AppContext';

interface AddTransactionModalProps {
  onClose: () => void;
  initialData?: PartialTransaction | null;
  transactionToEdit?: Transaction | null;
  startAsOrder?: boolean;
}

const SegmentedControl: React.FC<{
    options: { value: string; label: string; activeClassName: string; inactiveClassName?: string }[];
    value: string;
    onChange: (value: string) => void;
}> = ({ options, value, onChange }) => (
    <div className="flex w-full rounded-xl bg-light-bg-inset dark:bg-dark-bg-inset p-1">
        {options.map(opt => (
            <button
                key={opt.value}
                type="button"
                onClick={() => onChange(opt.value)}
                className={`w-full p-2.5 rounded-lg font-semibold transition-all duration-300 text-sm focus:outline-none
                    ${value === opt.value
                        ? `${opt.activeClassName} shadow`
                        : `${opt.inactiveClassName || 'text-light-fg-subtle dark:text-dark-fg-subtle hover:bg-light-bg-subtle/50 dark:hover:bg-dark-bg-subtle/50'}`
                }`
                }
            >
                {opt.label}
            </button>
        ))}
    </div>
);

const AddTransactionModal: React.FC<AddTransactionModalProps> = ({ 
    onClose, initialData, transactionToEdit, startAsOrder
}) => {
  const { 
    activeBusiness, 
    appData,
    dataForActiveBusiness,
    addTransaction,
    updateTransaction,
    addCategory,
    addClient,
    addVendor,
    addItem
  } = useAppContext();

  const { clients, vendors } = dataForActiveBusiness;
  const { categories, items } = appData;
  const currency = activeBusiness?.currency || '';

  const isEditMode = !!transactionToEdit;
  const dataToLoad = isEditMode ? transactionToEdit : initialData;

  const [type, setType] = useState<TransactionType>(startAsOrder ? TransactionType.INCOME : TransactionType.EXPENSE);
  const [itemId, setItemId] = useState('');
  const [showNewItemInput, setShowNewItemInput] = useState(false);
  const [newItemName, setNewItemName] = useState('');

  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState('');
  const [isBill, setIsBill] = useState(false);
  const [isOrder, setIsOrder] = useState(startAsOrder || !!transactionToEdit?.orderStatus);

  const [receiptImage, setReceiptImage] = useState<string | undefined>(undefined);
  const [receiptName, setReceiptName] = useState<string>('');
  const [nature, setNature] = useState<'service' | 'product'>('service');
  
  const [quantity, setQuantity] = useState('');
  const [unitPrice, setUnitPrice] = useState('');

  const [category, setCategory] = useState('');
  const [showNewCategoryInput, setShowNewCategoryInput] = useState(false);
  const [newCategory, setNewCategory] = useState('');
  const [newExpenseType, setNewExpenseType] = useState<ExpenseType | ''>('');
  const [isRecommending, setIsRecommending] = useState(false);
  
  const [clientId, setClientId] = useState<string | undefined>(undefined);
  const [vendorId, setVendorId] = useState<string | undefined>(undefined);

  // Order tracking state
  const [orderStatus, setOrderStatus] = useState<'pending' | 'in_progress' | 'ready_for_pickup' | 'shipped' | 'completed' | 'cancelled'>('pending');
  const [fulfillmentType, setFulfillmentType] = useState<'in-house' | 'outsourced'>('in-house');
  const [deliveryMethod, setDeliveryMethod] = useState<'pickup' | 'delivery' | 'digital' | 'shipping'>('delivery');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [shippingNotes, setShippingNotes] = useState('');

  const [subModal, setSubModal] = useState<'client' | 'vendor' | null>(null);

  useEffect(() => {
    if (dataToLoad) {
        if (dataToLoad.type) setType(dataToLoad.type);
        if (dataToLoad.description) setDescription(dataToLoad.description);
        if (dataToLoad.amount) setAmount(String(dataToLoad.amount));
        if (dataToLoad.date) setDate(new Date(dataToLoad.date).toISOString().split('T')[0]);
        if (isEditMode && 'dueDate' in dataToLoad && dataToLoad.dueDate) {
            setDueDate(new Date(dataToLoad.dueDate).toISOString().split('T')[0]);
            setIsBill(true);
        }
        if (dataToLoad.nature) setNature(dataToLoad.nature);
        if (dataToLoad.quantity) setQuantity(String(dataToLoad.quantity));
        if (dataToLoad.unitPrice) setUnitPrice(String(dataToLoad.unitPrice));
        if (dataToLoad.clientId) setClientId(dataToLoad.clientId);
        if (dataToLoad.vendorId) setVendorId(dataToLoad.vendorId);
        if (isEditMode && 'receiptImage' in dataToLoad && dataToLoad.receiptImage) {
            setReceiptImage(dataToLoad.receiptImage);
            setReceiptName('receipt.jpg');
        }

        // Order tracking fields
        if(dataToLoad.orderStatus) {
            setIsOrder(true);
            setOrderStatus(dataToLoad.orderStatus);
            setFulfillmentType(dataToLoad.fulfillmentType || 'in-house');
            setDeliveryMethod(dataToLoad.deliveryMethod || 'delivery');
            setTrackingNumber(dataToLoad.trackingNumber || '');
            setShippingNotes(dataToLoad.shippingNotes || '');
        }
        
        const itemExists = items.find(i => i.name.toLowerCase() === dataToLoad.name?.toLowerCase());
        if (itemExists) {
            setItemId(itemExists.id);
        } else if(dataToLoad.name) {
            setShowNewItemInput(true);
            setNewItemName(dataToLoad.name);
            setItemId('add_new_item');
        }

        const categoryExists = categories.find(c => c.name.toLowerCase() === dataToLoad.category?.toLowerCase() && c.type === (dataToLoad.type || type));
        if (categoryExists) {
            setCategory(categoryExists.name);
        } else if(dataToLoad.category) {
            setShowNewCategoryInput(true);
            setNewCategory(dataToLoad.category);
            setCategory('add_new');
        }
    }
  }, [dataToLoad, items, categories, type, isEditMode]);
  
  const relevantCategories = useMemo(() => {
    return categories.filter(cat => cat.type === type);
  }, [categories, type]);

  const relevantItems = useMemo(() => {
    return items.filter(item => item.type === type);
  }, [items, type]);

  useEffect(() => {
    if (!initialData) {
        setCategory('');
        setShowNewCategoryInput(false);
        setNewCategory('');
        setNewExpenseType('');
        setItemId('');
        setShowNewItemInput(false);
        setNewItemName('');
        setIsBill(false);
        setDueDate('');
        setIsOrder(startAsOrder || false);
    }
  }, [type, initialData, startAsOrder]);

  useEffect(() => {
    if (type === TransactionType.EXPENSE) {
        setIsOrder(false);
    }
  }, [type]);

  useEffect(() => {
    if (nature === 'product') {
        const q = parseFloat(quantity);
        const p = parseFloat(unitPrice);
        if (!isNaN(q) && !isNaN(p)) {
            setAmount(String(q * p));
        } else {
            setAmount('');
        }
    }
  }, [quantity, unitPrice, nature]);

  const handleItemChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedId = e.target.value;
    if (selectedId === 'add_new_item') {
      setShowNewItemInput(true);
      setItemId('add_new_item');
    } else {
      setShowNewItemInput(false);
      setItemId(selectedId);
      const selectedItem = items.find(i => i.id === selectedId);
      if (selectedItem) {
        setNature(selectedItem.nature);
        if (selectedItem.nature === 'product' && selectedItem.unitPrice) {
          setUnitPrice(String(selectedItem.unitPrice));
        } else {
          setUnitPrice('');
        }
      }
    }
  };

  const handleReceiptChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReceiptImage(reader.result as string);
        setReceiptName(file.name);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    if (e.target.value === 'add_new') {
      setShowNewCategoryInput(true);
      setCategory('add_new');
    } else {
      setShowNewCategoryInput(false);
      setCategory(e.target.value);
    }
  };
  
  const handleVendorChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    if (e.target.value === 'add_new_vendor') {
      setSubModal('vendor');
    } else {
      setVendorId(e.target.value);
    }
  };

  const handleClientChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    if (e.target.value === 'add_new_client') {
      setSubModal('client');
    } else {
      setClientId(e.target.value);
    }
  };

  const handleSuggestType = async () => {
    if (!newCategory.trim() || isRecommending) return;
    setIsRecommending(true);
    try {
        const recommendedType = await recommendExpenseType(newCategory);
        if (recommendedType) {
            setNewExpenseType(recommendedType);
        }
    } catch (error) {
        console.error("Failed to suggest expense type", error);
    } finally {
        setIsRecommending(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let finalCategory = category;
    if (showNewCategoryInput && newCategory.trim()) {
        if (type === TransactionType.EXPENSE && !newExpenseType) {
            alert("Please select an expense type for the new category.");
            return;
        }
        finalCategory = newCategory.trim();
        addCategory(finalCategory, type, newExpenseType || undefined);
    }

    let finalName = '';
    if (showNewItemInput && newItemName.trim()) {
        finalName = newItemName.trim();
        const newItemData = {
            name: finalName,
            type,
            nature,
            unitPrice: nature === 'product' ? parseFloat(unitPrice) : undefined
        };
        addItem(newItemData);
    } else if (itemId) {
        finalName = items.find(i => i.id === itemId)?.name || '';
    }

    if (!finalName || !amount || !finalCategory || finalCategory === 'add_new' || !date) {
        alert("Please fill all required fields.");
        return;
    }
    
    const transactionData: Omit<Transaction, 'id' | 'businessId' | 'transactionNumber' | 'status' | 'payments'> = {
      type,
      name: finalName,
      description,
      amount: parseFloat(amount),
      category: finalCategory,
      date: new Date(date).toISOString(),
      dueDate: (isBill || isOrder) && dueDate ? new Date(dueDate).toISOString() : undefined,
      receiptImage,
      clientId: type === TransactionType.INCOME ? clientId : undefined,
      vendorId: (type === TransactionType.EXPENSE || (isOrder && fulfillmentType === 'outsourced')) ? vendorId : undefined,
      nature,
      quantity: nature === 'product' ? parseFloat(quantity) : undefined,
      unitPrice: nature === 'product' ? parseFloat(unitPrice) : undefined,
      orderStatus: isOrder ? orderStatus : undefined,
      fulfillmentType: isOrder ? fulfillmentType : undefined,
      deliveryMethod: isOrder ? deliveryMethod : undefined,
      trackingNumber: isOrder ? trackingNumber : undefined,
      shippingNotes: isOrder ? shippingNotes : undefined,
    };
    
    if (isEditMode && transactionToEdit) {
        updateTransaction({
            ...transactionToEdit,
            ...transactionData,
        });
    } else {
        addTransaction(transactionData, isBill);
    }
    
    onClose();
  };
  
  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };
  
  const baseInputClasses = "w-full bg-light-bg-inset dark:bg-dark-bg-inset border-2 border-transparent rounded-xl focus:outline-none focus:ring-0 text-light-fg-default dark:text-dark-fg-default placeholder:text-light-fg-subtle placeholder:dark:text-dark-fg-subtle transition-colors";
  const focusClasses = "focus-within:ring-2 focus-within:ring-accent focus-within:border-transparent";

  const commonSelectClasses = `${baseInputClasses} ${focusClasses} py-3 px-4`;
  const commonTextareaClasses = `${baseInputClasses} ${focusClasses} py-3 px-4`;
  const currencyInputWrapperClasses = `${baseInputClasses} ${focusClasses} flex items-center`;
  const currencyInputClasses = "w-full bg-transparent p-0 pl-2 pr-4 py-3 focus:outline-none focus:ring-0 border-none";
  const commonLabelClasses = "block text-sm font-medium mb-1.5 text-light-fg-subtle dark:text-dark-fg-subtle";

  return (
    <>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in" onClick={handleBackdropClick}>
        <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl shadow-2xl w-full max-w-md m-4 p-6 relative animate-slide-up border border-light-border-default/50 dark:border-dark-border-default max-h-[90vh] overflow-y-auto">
          <button onClick={onClose} className="absolute top-4 right-4 text-light-fg-subtle dark:text-dark-fg-subtle hover:text-light-fg-default dark:hover:text-dark-fg-default">
            <CloseIcon />
          </button>
          <h2 className="text-xl font-bold mb-6 text-light-fg-default dark:text-dark-fg-default">
            {isEditMode ? 'Edit Transaction' : (initialData ? 'Review Transaction' : 'Add Transaction')}
          </h2>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
                 <SegmentedControl
                    value={type}
                    onChange={(val) => setType(val as TransactionType)}
                    options={[
                        { value: 'expense', label: 'Expense', activeClassName: 'bg-light-expense-bg text-light-expense-fg dark:bg-dark-expense-bg dark:text-dark-expense-fg' },
                        { value: 'income', label: 'Income', activeClassName: 'bg-light-income-bg text-light-income-fg dark:bg-dark-income-bg dark:text-dark-income-fg' }
                    ]}
                />
                <SegmentedControl
                    value={nature}
                    onChange={(val) => setNature(val as 'service' | 'product')}
                    options={[
                        { value: 'service', label: 'Service', activeClassName: 'bg-light-bg-default dark:bg-dark-bg-default text-accent' },
                        { value: 'product', label: 'Product', activeClassName: 'bg-light-bg-default dark:bg-dark-bg-default text-accent' }
                    ]}
                />
            </div>
            
            <select value={itemId} onChange={handleItemChange} className={commonSelectClasses} required>
              <option value="" disabled>{type === 'income' ? 'Select Product/Service' : 'Select Expense Item'}</option>
              {relevantItems.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
              <option value="add_new_item" className="font-bold text-accent">Add New Item...</option>
            </select>
            
            {showNewItemInput && (
              <div className="p-3 bg-light-bg-inset dark:bg-dark-bg-inset rounded-lg">
                <input type="text" placeholder="New Item Name" value={newItemName} onChange={e => setNewItemName(e.target.value)} className={commonTextareaClasses} required />
              </div>
            )}

            <input type="text" placeholder="Description (Optional)" value={description} onChange={e => setDescription(e.target.value)} className={commonTextareaClasses} />
            
            {nature === 'service' ? (
                <div>
                    <label htmlFor="amount" className={commonLabelClasses}>Amount</label>
                    <div className={currencyInputWrapperClasses}>
                      <span className="pl-4 pr-2 text-light-fg-subtle dark:text-dark-fg-subtle">{currency}</span>
                      <input
                          id="amount"
                          type="number"
                          placeholder="0.00"
                          value={amount}
                          onChange={e => setAmount(e.target.value)}
                          className={currencyInputClasses}
                          required
                          step="0.01"
                      />
                    </div>
                </div>
            ) : (
                 <div className="flex items-end gap-2">
                    <div className="flex-1">
                        <label htmlFor="quantity" className={commonLabelClasses}>Quantity</label>
                        <input
                            id="quantity"
                            type="number"
                            placeholder="0"
                            value={quantity}
                            onChange={e => setQuantity(e.target.value)}
                            className={commonTextareaClasses}
                            required
                        />
                    </div>
                    <span className="text-light-fg-subtle dark:text-dark-fg-subtle pb-3 text-lg">×</span>
                    <div className="flex-1">
                        <label htmlFor="unit-price" className={commonLabelClasses}>Unit Price</label>
                         <div className={currencyInputWrapperClasses}>
                            <span className="pl-4 pr-2 text-light-fg-subtle dark:text-dark-fg-subtle">{currency}</span>
                            <input
                                id="unit-price"
                                type="number"
                                placeholder="0.00"
                                value={unitPrice}
                                onChange={e => setUnitPrice(e.target.value)}
                                className={currencyInputClasses}
                                required
                                step="0.01"
                            />
                        </div>
                    </div>
                </div>
            )}
            
            {nature === 'product' && (
                <div className="flex justify-between items-center py-3 px-4 rounded-xl bg-light-bg-inset dark:bg-dark-bg-inset">
                    <span className="font-semibold text-light-fg-default dark:text-dark-fg-default">Total Amount</span>
                    <span className="font-bold text-xl text-light-fg-default dark:text-dark-fg-default">
                        {currency} {parseFloat(amount || '0').toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                    </span>
                </div>
            )}

            <select value={category} onChange={handleCategoryChange} className={commonSelectClasses} required>
              <option value="" disabled>Select Category</option>
              {relevantCategories.map(cat => <option key={cat.id} value={cat.name}>{cat.name}</option>)}
              <option value="add_new" className="font-bold text-accent">Add New Category...</option>
            </select>

            {showNewCategoryInput && (
              <div className="space-y-2 p-3 bg-light-bg-inset dark:bg-dark-bg-inset rounded-lg">
                <input type="text" placeholder="New Category Name" value={newCategory} onChange={e => setNewCategory(e.target.value)} className={commonTextareaClasses} required />
                {type === TransactionType.EXPENSE && (
                  <div className="relative">
                    <select value={newExpenseType} onChange={e => setNewExpenseType(e.target.value as ExpenseType)} className={commonSelectClasses + " pr-12"} required disabled={isRecommending}>
                      <option value="" disabled>Select Expense Type</option>
                      {expenseTypes.map(et => <option key={et} value={et}>{et}</option>)}
                    </select>
                    <button
                      type="button"
                      onClick={handleSuggestType}
                      disabled={isRecommending || !newCategory.trim()}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-accent disabled:text-light-fg-subtle disabled:cursor-not-allowed transition-all"
                      title="Suggest with AI"
                    >
                      {isRecommending ? <SpinnerIcon className="w-5 h-5"/> : <SparklesIcon className="w-5 h-5" />}
                    </button>
                  </div>
                )}
              </div>
            )}

            {type === TransactionType.INCOME && (
              <select value={clientId || ''} onChange={handleClientChange} className={commonSelectClasses} required={isOrder}>
                <option value="">Select Client</option>
                {clients.map(client => <option key={client.id} value={client.id}>{client.name}</option>)}
                <option value="add_new_client" className="font-bold text-accent">Add New Client...</option>
              </select>
            )}

            {type === TransactionType.EXPENSE && (
              <select value={vendorId || ''} onChange={handleVendorChange} className={commonSelectClasses}>
                <option value="">Select Vendor (Optional)</option>
                {vendors.map(vendor => <option key={vendor.id} value={vendor.id}>{vendor.name}</option>)}
                 <option value="add_new_vendor" className="font-bold text-accent">Add New Vendor...</option>
              </select>
            )}
            
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label htmlFor="date" className={commonLabelClasses}>Date</label>
                    <input id="date" type="date" value={date} onChange={e => setDate(e.target.value)} className={commonTextareaClasses} required />
                </div>
                 {(isBill || isOrder) && (
                    <div>
                        <label htmlFor="due-date" className={commonLabelClasses}>Due Date</label>
                        <input id="due-date" type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} className={commonTextareaClasses} required />
                    </div>
                )}
            </div>
            
            {type === TransactionType.EXPENSE && !isEditMode && (
                <div className="flex items-center gap-2 p-2">
                     <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" checked={isBill} onChange={(e) => setIsBill(e.target.checked)} className="sr-only peer" />
                        <div className="w-11 h-6 bg-light-bg-inset dark:bg-dark-bg-inset peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent"></div>
                    </label>
                    <span className="text-sm font-medium text-light-fg-subtle dark:text-dark-fg-subtle">Is this a bill to be paid later?</span>
                </div>
            )}

            {type === TransactionType.INCOME && (
                <div className="p-2 border-t border-light-border-default dark:border-dark-border-default">
                    <div className="flex items-center gap-2">
                        <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" checked={isOrder} onChange={(e) => setIsOrder(e.target.checked)} className="sr-only peer" />
                            <div className="w-11 h-6 bg-light-bg-inset dark:bg-dark-bg-inset peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent"></div>
                        </label>
                        <span className="text-sm font-medium text-light-fg-subtle dark:text-dark-fg-subtle">Advanced: Track as an Order</span>
                    </div>
                </div>
            )}

            {isOrder && (
                <div className="space-y-4 p-4 bg-light-bg-inset dark:bg-dark-bg-inset rounded-lg">
                    <div>
                        <label className={commonLabelClasses}>Order Status</label>
                        <select value={orderStatus} onChange={e => setOrderStatus(e.target.value as any)} className={commonSelectClasses}>
                            <option value="pending">Pending</option>
                            <option value="in_progress">In Progress</option>
                            <option value="ready_for_pickup">Ready for Pickup</option>
                            <option value="shipped">Shipped</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                     <div>
                        <label className={commonLabelClasses}>Fulfillment Type</label>
                        <SegmentedControl 
                            value={fulfillmentType}
                            onChange={v => setFulfillmentType(v as any)}
                            options={[
                                { value: 'in-house', label: 'In-house', activeClassName: 'bg-light-bg-default dark:bg-dark-bg-default text-accent' },
                                { value: 'outsourced', label: 'Outsourced', activeClassName: 'bg-light-bg-default dark:bg-dark-bg-default text-accent' }
                            ]}
                        />
                    </div>
                    {fulfillmentType === 'outsourced' && (
                        <select value={vendorId || ''} onChange={handleVendorChange} className={commonSelectClasses}>
                            <option value="">Select Vendor</option>
                            {vendors.map(vendor => <option key={vendor.id} value={vendor.id}>{vendor.name}</option>)}
                            <option value="add_new_vendor" className="font-bold text-accent">Add New Vendor...</option>
                        </select>
                    )}
                     <div>
                        <label className={commonLabelClasses}>Delivery Method</label>
                        <select value={deliveryMethod} onChange={e => setDeliveryMethod(e.target.value as any)} className={commonSelectClasses}>
                            <option value="pickup">Pickup</option>
                            <option value="delivery">Local Delivery</option>
                            <option value="shipping">Shipping</option>
                            <option value="digital">Digital</option>
                        </select>
                    </div>
                    <div>
                        <label className={commonLabelClasses}>Tracking Number (Optional)</label>
                        <input type="text" value={trackingNumber} onChange={e => setTrackingNumber(e.target.value)} placeholder="e.g. 1Z999AA10123456789" className={commonTextareaClasses} />
                    </div>
                    <div>
                        <label className={commonLabelClasses}>Shipping Notes (Optional)</label>
                        <textarea value={shippingNotes} onChange={e => setShippingNotes(e.target.value)} placeholder="e.g. Leave at front door" className={commonTextareaClasses} rows={2}></textarea>
                    </div>
                </div>
            )}

             <div>
              <label htmlFor="receipt-upload" className={`${commonTextareaClasses} cursor-pointer flex items-center justify-center text-light-fg-subtle dark:text-dark-fg-subtle`}>
                📎 {receiptName || (receiptImage ? 'Receipt Attached' : 'Attach Receipt')}
              </label>
              <input id="receipt-upload" type="file" accept="image/*" capture="environment" onChange={handleReceiptChange} className="hidden" />
            </div>

            <button type="submit" className="w-full bg-accent text-accent-fg font-bold py-3.5 px-4 rounded-xl hover:opacity-90 transition-opacity">
                {isEditMode ? 'Update Transaction' : (initialData ? 'Confirm Transaction' : 'Add Transaction')}
            </button>
          </form>
        </div>
      </div>
      
      {subModal === 'client' && (
        <AddClientModal
          onClose={() => setSubModal(null)}
          onAddClient={clientData => {
            const newClient = addClient(clientData);
            setClientId(newClient.id);
            setSubModal(null);
          }}
        />
      )}
      {subModal === 'vendor' && (
        <AddVendorModal
          onClose={() => setSubModal(null)}
          onAddVendor={vendorData => {
            const newVendor = addVendor(vendorData);
            setVendorId(newVendor.id);
            setSubModal(null);
          }}
        />
      )}
    </>
  );
};

export default AddTransactionModal;
