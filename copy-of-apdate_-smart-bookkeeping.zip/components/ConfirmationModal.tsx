import React from 'react';
import { CloseIcon } from './icons/CloseIcon';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: React.ReactNode;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ isOpen, onClose, onConfirm, title, message }) => {
  if (!isOpen) return null;

  const handleConfirm = () => {
    onConfirm();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in" onClick={onClose}>
      <div 
        className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl shadow-2xl w-full max-w-sm m-4 p-6 relative animate-slide-up border border-light-border-default/50 dark:border-dark-border-default" 
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-xl font-bold mb-4 text-light-fg-default dark:text-dark-fg-default">{title}</h2>
        <div className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">
          {message}
        </div>
        <div className="flex gap-3 mt-6">
          <button 
            onClick={onClose} 
            className="flex-1 bg-light-bg-inset dark:bg-dark-bg-inset text-light-fg-default dark:text-dark-fg-default font-bold py-3 px-4 rounded-xl hover:opacity-80 transition-opacity"
          >
            Cancel
          </button>
          <button 
            onClick={handleConfirm} 
            className="flex-1 bg-destructive text-destructive-fg font-bold py-3 px-4 rounded-xl hover:opacity-90 transition-opacity"
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;