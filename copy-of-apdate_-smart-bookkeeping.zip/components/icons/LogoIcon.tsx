import React from 'react';

export const LogoIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 152 40" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
             <linearGradient id="paint0_linear_logo_icon" x1="17" y1="5.625" x2="17" y2="33.75" gradientUnits="userSpaceOnUse">
                <stop stopColor="#3B82F6"/>
                <stop offset="1" stopColor="#2563EB"/>
            </linearGradient>
            <radialGradient id="paint1_radial_logo_icon" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(144.5 31.5) rotate(90) scale(4.5)">
                <stop stopColor="#60A5FA"/>
                <stop offset="1" stopColor="#3B82F6"/>
            </radialGradient>
        </defs>
        <g transform="scale(0.8) translate(0, 5)">
            <path d="M32.333 21.25C32.333 24.5417 31.222 27.3125 29.000 29.5625C26.778 31.8125 23.611 33.0625 19.500 33.0625H13.500C9.389 33.0625 6.222 31.8125 4.000 29.5625C1.778 27.3125 0.667 24.5417 0.667 21.25V19.1875H32.333V21.25Z" fill="url(#paint0_linear_logo_icon)"/>
            <path d="M35.667 16.25H-1.333C-1.333 9.875 1.333 4.875 6.667 1.25C12.000 -2.375 16.667 -4.375 17.000 -4.375C19.667 -4.375 24.167 -2.375 29.500 1.25C34.833 4.875 35.667 9.875 35.667 16.25Z" fill="url(#paint0_linear_logo_icon)"/>
        </g>
        <text x="46" y="31" fontFamily="Inter, sans-serif" fontSize="28" fontWeight="600" className="fill-light-fg-default dark:fill-dark-fg-default">Apdate</text>
        <circle cx="144.5" cy="31.5" r="4.5" fill="url(#paint1_radial_logo_icon)"/>
        <text x="127" y="31" fontFamily="Inter, sans-serif" fontSize="28" fontWeight="600" className="fill-light-fg-default dark:fill-dark-fg-default">.</text>
    </svg>
);