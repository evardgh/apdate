
import React from 'react';
import { LogoIcon } from './icons/LogoIcon';
import { BackIcon } from './icons/BackIcon';
import { View } from '../types';
import { HelpIcon } from './icons/HelpIcon';
import { useAppContext } from '../context/AppContext';

interface HeaderProps {
    view: View;
    onBack?: () => void;
    onHelpClick?: () => void;
}

const Header: React.FC<HeaderProps> = ({ view, onBack, onHelpClick }) => {
    const { activeBusiness } = useAppContext();

    const getTitle = () => {
        if (view === 'dashboard') return activeBusiness?.name || 'Dashboard';
        if (view === 'ai') return "Apdate AI";
        
        // Capitalize the first letter of the view name
        return view.charAt(0).toUpperCase() + view.slice(1);
    };

    return (
        <header className="p-4 bg-light-bg-subtle/80 dark:bg-dark-bg-subtle/80 backdrop-blur-lg border-b border-light-border-default dark:border-dark-border-default sticky top-0 z-20 flex items-center justify-between h-16">
            <div className="flex items-center w-1/3">
                {onBack ? (
                    <button onClick={onBack} className="p-2 -ml-2 text-light-fg-default dark:text-dark-fg-default">
                        <BackIcon />
                    </button>
                ) : (
                    <LogoIcon className="h-9 w-auto" />
                )}
            </div>
            
            <div className="w-1/3 text-center">
                <h1 className="text-base font-semibold text-light-fg-default dark:text-dark-fg-default truncate">
                   {getTitle()}
                </h1>
            </div>

            <div className="w-1/3 flex justify-end items-center">
                 {onHelpClick && (
                    <button onClick={onHelpClick} className="p-1 text-light-fg-subtle dark:text-dark-fg-subtle hover:text-accent dark:hover:text-accent transition-colors">
                        <HelpIcon />
                    </button>
                )}
            </div>
        </header>
    );
};

export default Header;
