
import React, { useState, useEffect, useMemo } from 'react';
import { Quotation, QuotationItem, Business, Client, Item, TransactionType } from '../types';
import { CloseIcon } from './icons/CloseIcon';
import { TrashIcon } from './icons/TrashIcon';
import AddClientModal from './AddClientModal';
import { useAppContext } from '../context/AppContext';

interface CreateDocumentModalProps {
  mode: 'invoice' | 'quotation';
  quoteToEdit?: Quotation;
  initialData?: { clientId: string, items: QuotationItem[] };
  onClose: () => void;
  onSaveQuote: (quote: any) => void;
  onSaveInvoice: (quote: any) => void;
}

const CreateDocumentModal: React.FC<CreateDocumentModalProps> = ({ mode, quoteToEdit, initialData, onClose, onSaveQuote, onSaveInvoice }) => {
  const { 
    activeBusiness, 
    dataForActiveBusiness, 
    appData, 
    addClient, 
    addItem 
  } = useAppContext();

  const { clients } = dataForActiveBusiness;
  const { items } = appData;
  const business = activeBusiness;

  const isEditMode = !!quoteToEdit;
  
  const [clientId, setClientId] = useState(quoteToEdit?.clientId || '');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  
  const [paymentTerms, setPaymentTerms] = useState(business?.paymentTerms || 15);

  const [lineItems, setLineItems] = useState<QuotationItem[]>(quoteToEdit?.items || [{ id: ''+Date.now(), name: '', quantity: 1, unitPrice: 0 }]);
  const [taxRate, setTaxRate] = useState(quoteToEdit?.taxRate || business?.taxRate || 0);
  const [notes, setNotes] = useState(quoteToEdit?.notes || business?.invoiceNotes || '');

  const [subModal, setSubModal] = useState<'client' | null>(null);

  const expiryDate = useMemo(() => {
    const d = new Date(date);
    d.setDate(d.getDate() + paymentTerms);
    return d.toISOString().split('T')[0];
  }, [date, paymentTerms]);

  useEffect(() => {
    if (quoteToEdit) {
      setClientId(quoteToEdit.clientId);
      setDate(new Date(quoteToEdit.date).toISOString().split('T')[0]);
      setLineItems(quoteToEdit.items);
      setTaxRate(quoteToEdit.taxRate);
      setNotes(quoteToEdit.notes || '');
      // Infer payment terms if possible
      const issueDate = new Date(quoteToEdit.date);
      const expDate = new Date(quoteToEdit.expiryDate);
      const diffTime = Math.abs(expDate.getTime() - issueDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      setPaymentTerms(diffDays);
    }
  }, [quoteToEdit]);
  
  useEffect(() => {
    if (initialData) {
        if (initialData.clientId) {
            setClientId(initialData.clientId);
        }
        if (initialData.items && initialData.items.length > 0) {
            setLineItems(initialData.items.map(item => ({...item, id: ''+Date.now()})));
        } else {
            setLineItems([{ id: ''+Date.now(), name: '', quantity: 1, unitPrice: 0 }])
        }
    }
  }, [initialData]);

  const handleLineItemChange = (index: number, field: keyof QuotationItem, value: any) => {
    const updatedItems = [...lineItems];
    (updatedItems[index] as any)[field] = value;
    setLineItems(updatedItems);
  };
  
  const addLineItem = () => {
    setLineItems([...lineItems, { id: ''+Date.now(), name: '', quantity: 1, unitPrice: 0 }]);
  };

  const removeLineItem = (index: number) => {
    setLineItems(lineItems.filter((_, i) => i !== index));
  };

  const subtotal = useMemo(() => lineItems.reduce((acc, item) => acc + (item.quantity * item.unitPrice), 0), [lineItems]);
  const total = useMemo(() => subtotal * (1 + taxRate / 100), [subtotal, taxRate]);

  const handleSubmit = () => {
    if (!clientId) {
      alert('Please select a client.');
      return;
    }
    if (lineItems.some(item => !item.name.trim() || item.quantity <= 0 || item.unitPrice < 0)) {
      alert('Please ensure all line items have a name, positive quantity, and valid price.');
      return;
    }

    const documentData = {
      id: quoteToEdit?.id,
      clientId,
      date: new Date(date).toISOString(),
      expiryDate: new Date(expiryDate).toISOString(),
      items: lineItems,
      subtotal,
      taxRate,
      total,
      notes,
      status: quoteToEdit?.status || 'draft',
    };
    
    // Add new items to global items list
    lineItems.forEach(lineItem => {
        const exists = items.some(i => i.name.toLowerCase() === lineItem.name.toLowerCase());
        if(!exists) {
            addItem({ name: lineItem.name, type: TransactionType.INCOME, nature: 'service', unitPrice: lineItem.unitPrice });
        }
    });

    if (mode === 'quotation') {
      onSaveQuote(documentData);
    } else {
      onSaveInvoice(documentData);
    }
    onClose();
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };
  
  const incomeItems = items.filter(i => i.type === TransactionType.INCOME);

  if (!business) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in" onClick={handleBackdropClick}>
        <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl shadow-2xl w-full max-w-lg m-4 max-h-[90vh] flex flex-col animate-slide-up border border-light-border-default/50 dark:border-dark-border-default">
          <div className="flex items-center justify-between p-4 border-b border-light-border-default dark:border-dark-border-default">
            <h2 className="text-xl font-bold text-light-fg-default dark:text-dark-fg-default capitalize">{isEditMode ? 'Edit' : 'Create'} {mode}</h2>
            <button onClick={onClose}><CloseIcon /></button>
          </div>

          <div className="p-6 overflow-y-auto space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <select value={clientId} onChange={e => e.target.value === 'add_new' ? setSubModal('client') : setClientId(e.target.value)} className="w-full bg-light-bg-inset dark:bg-dark-bg-inset border-transparent focus:border-accent border-2 rounded-xl py-3 px-4 focus:outline-none focus:ring-0">
                <option value="" disabled>Select Client</option>
                {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                <option value="add_new" className="font-bold text-accent">Add New Client...</option>
              </select>
            </div>
            
            {/* Line Items */}
            <div className="space-y-3">
              {lineItems.map((item, index) => (
                <div key={item.id} className="grid grid-cols-12 gap-2 p-3 bg-light-bg-inset dark:bg-dark-bg-inset rounded-lg">
                  <div className="col-span-12 sm:col-span-5">
                    <label className="text-xs text-light-fg-subtle dark:text-dark-fg-subtle">Item</label>
                    <input type="text" list="item-suggestions" value={item.name} onChange={e => handleLineItemChange(index, 'name', e.target.value)} placeholder="Item Name" className="w-full bg-light-bg-subtle dark:bg-dark-bg-subtle border-transparent rounded-lg p-2 text-sm"/>
                    <datalist id="item-suggestions">
                        {incomeItems.map(i => <option key={i.id} value={i.name} />)}
                    </datalist>
                  </div>
                  <div className="col-span-4 sm:col-span-2">
                    <label className="text-xs text-light-fg-subtle dark:text-dark-fg-subtle">Qty</label>
                    <input type="number" value={item.quantity} onChange={e => handleLineItemChange(index, 'quantity', parseFloat(e.target.value))} className="w-full bg-light-bg-subtle dark:bg-dark-bg-subtle border-transparent rounded-lg p-2 text-sm"/>
                  </div>
                  <div className="col-span-8 sm:col-span-4">
                    <label className="text-xs text-light-fg-subtle dark:text-dark-fg-subtle">Unit Price</label>
                    <input type="number" value={item.unitPrice} onChange={e => handleLineItemChange(index, 'unitPrice', parseFloat(e.target.value))} className="w-full bg-light-bg-subtle dark:bg-dark-bg-subtle border-transparent rounded-lg p-2 text-sm"/>
                  </div>
                  <div className="col-span-1 flex items-end">
                    <button onClick={() => removeLineItem(index)} className="text-destructive"><TrashIcon className="w-5 h-5"/></button>
                  </div>
                </div>
              ))}
              <button onClick={addLineItem} className="text-sm font-semibold text-accent">+ Add Line Item</button>
            </div>

            {/* Totals */}
            <div className="flex justify-end">
                <div className="w-full max-w-xs space-y-2 text-sm">
                    <div className="flex justify-between"><span>Subtotal</span><span>{business.currency} {subtotal.toLocaleString()}</span></div>
                    <div className="flex justify-between items-center">
                        <span>Tax (%)</span>
                        <input type="number" value={taxRate} onChange={e => setTaxRate(parseFloat(e.target.value))} className="w-20 bg-light-bg-inset dark:bg-dark-bg-inset border-transparent rounded p-1 text-right"/>
                    </div>
                    <div className="flex justify-between font-bold text-base border-t pt-2 mt-2"><span>Total</span><span>{business.currency} {total.toLocaleString()}</span></div>
                </div>
            </div>

            <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Notes (e.g., payment terms)" rows={3} className="w-full bg-light-bg-inset dark:bg-dark-bg-inset border-transparent rounded-lg p-2 text-sm"></textarea>
            
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-xs text-light-fg-subtle dark:text-dark-fg-subtle">Issue Date</label>
                    <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full bg-light-bg-inset dark:bg-dark-bg-inset border-transparent rounded-lg p-2 text-sm"/>
                </div>
                 <div>
                    <label className="text-xs text-light-fg-subtle dark:text-dark-fg-subtle">Payment Terms</label>
                    <select value={paymentTerms} onChange={e => setPaymentTerms(Number(e.target.value))} className="w-full bg-light-bg-inset dark:bg-dark-bg-inset border-transparent rounded-lg p-2 text-sm">
                        <option value={0}>Due on receipt</option>
                        <option value={7}>Net 7</option>
                        <option value={15}>Net 15</option>
                        <option value={30}>Net 30</option>
                        <option value={60}>Net 60</option>
                    </select>
                </div>
            </div>
          </div>

          <div className="p-4 bg-light-bg-inset dark:bg-dark-bg-inset border-t border-light-border-default dark:border-dark-border-default">
            <button onClick={handleSubmit} className="w-full bg-accent text-accent-fg font-bold py-3 px-4 rounded-xl hover:opacity-90 transition-opacity">
              {isEditMode ? 'Update' : 'Save'} {mode}
            </button>
          </div>
        </div>
      </div>
      {subModal === 'client' && (
        <AddClientModal
          onClose={() => setSubModal(null)}
          onAddClient={clientData => {
            const newClient = addClient(clientData);
            setClientId(newClient.id);
            setSubModal(null);
          }}
        />
      )}
    </>
  );
};

export default CreateDocumentModal;
