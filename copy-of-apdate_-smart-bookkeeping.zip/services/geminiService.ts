import { GoogleGenAI } from "@google/genai";
import { Transaction, Client, Vendor, ExpenseType, expenseTypes, Category, Item, PartialTransaction, TransactionType, QuotationItem, Business } from '../types';

if (!process.env.API_KEY) {
    console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const getSystemInstruction = (
    transactions: Transaction[], 
    currency: string,
    clients: Client[],
    vendors: Vendor[]
) => {
    const transactionsString = JSON.stringify(transactions, null, 2);
    const clientsString = JSON.stringify(clients, null, 2);
    const vendorsString = JSON.stringify(vendors, null, 2);

    return `You are Apdate AI, a friendly and expert financial assistant for small business owners in Ghana. 
Your goal is to provide clear, insightful answers based on the user's financial data.
Analyze the provided JSON data of financial transactions to answer the user's questions. 
All monetary values are in ${currency}.
Today's date is ${new Date().toLocaleDateString()}.
Be concise and helpful. Start your response directly without preamble like "Okay, here is...".

Here is the user's transaction data. The 'name' is a short title for the transaction, and 'description' provides more detail.
${transactionsString}

Here is the user's client data. The 'clientId' in transactions corresponds to the 'id' in this list:
${clientsString}

Here is the user's vendor data. The 'vendorId' in transactions corresponds to the 'id' in this list:
${vendorsString}
`;
};


export const generateFinancialInsightStream = async (
    prompt: string, 
    transactions: Transaction[],
    currency: string,
    clients: Client[],
    vendors: Vendor[]
) => {
    const systemInstruction = getSystemInstruction(transactions, currency, clients, vendors);
    
    try {
        const response = await ai.models.generateContentStream({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
            },
        });
        return response;
    } catch (error) {
        console.error("Error generating content from Gemini:", error);
        throw new Error("Failed to get response from AI assistant.");
    }
};

export const recommendExpenseType = async (categoryName: string): Promise<ExpenseType | null> => {
    if (!categoryName.trim()) {
        return null;
    }

    const systemInstruction = `You are an expert accountant. Classify the user's expense category into one of these exact types: ${expenseTypes.join(', ')}.
Respond with ONLY the expense type string. No extra text, no explanations.
For example, if the category is "Website Hosting", you respond with "Operating Expenses". If it's "Raw Steel", you respond with "Cost of Goods Sold".`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: `Classify this expense category: "${categoryName}"`,
            config: {
                systemInstruction: systemInstruction,
                temperature: 0,
                thinkingConfig: { thinkingBudget: 0 }
            },
        });
        
        const recommendedType = response.text.trim();

        // Validate if the response is one of the allowed types
        if (expenseTypes.includes(recommendedType as ExpenseType)) {
            return recommendedType as ExpenseType;
        } else {
            console.warn(`Gemini returned an invalid expense type: "${recommendedType}"`);
            return null;
        }

    } catch (error) {
        console.error("Error recommending expense type from Gemini:", error);
        return null;
    }
};

export const getTermExplanation = async (term: string): Promise<string> => {
    const systemInstruction = `You are a friendly and helpful finance teacher for small business owners who may not be familiar with accounting.
Explain the following business finance term in simple, easy-to-understand language.
Keep the explanation concise, clear, and encouraging. Use an analogy if it helps. Do not use financial jargon in your explanation.
Respond with only the explanation text. No preamble.`;
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: `Term: "${term}"`,
            config: {
                systemInstruction: systemInstruction,
            },
        });
        
        return response.text.trim();

    } catch (error) {
        console.error(`Error explaining term "${term}" from Gemini:`, error);
        return "Sorry, I couldn't fetch an explanation at this moment. Please try again.";
    }
};

export const getScreenExplanation = async (screenName: string): Promise<string> => {
    const systemInstruction = `You are a friendly in-app guide for a bookkeeping app. 
Explain the purpose of the following screen to a small business owner who might be new to accounting.
Keep the explanation brief (2-3 sentences), simple, and encouraging. Focus on what the user can do on this screen.
Respond with only the explanation text. No preamble.`;
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: `Screen name: "${screenName}"`,
            config: {
                systemInstruction: systemInstruction,
            },
        });
        
        return response.text.trim();

    } catch (error) {
        console.error(`Error explaining screen "${screenName}" from Gemini:`, error);
        return "Sorry, I couldn't fetch an explanation at this moment. Please try again.";
    }
};

export const enhanceText = async (text: string): Promise<string> => {
    if (!text.trim()) return text;
    
    const systemInstruction = `You are a helpful proofreading assistant. Correct any spelling mistakes, fix the grammar, and improve the clarity of the following text. Make it sound professional and clear for a bookkeeping record.
Respond with ONLY the corrected text. Do not add any preamble or explanation.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: `Proofread and enhance this: "${text}"`,
            config: {
                systemInstruction,
                temperature: 0.2,
                thinkingConfig: { thinkingBudget: 0 }
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error enhancing text from Gemini:", error);
        return text; // Return original text on error
    }
};


export const parseTransactionFromText = async (
  text: string, 
  categories: Category[], 
  items: Item[], 
  clients: Client[],
  vendors: Vendor[]
): Promise<PartialTransaction | null> => {
    const systemInstruction = `You are an intelligent bookkeeping assistant. Your task is to parse a user's natural language input and convert it into a structured JSON object representing a financial transaction.

The user is a small business owner. The language might be informal.
Today's date is ${new Date().toISOString()}.
Infer dates from relative terms like "yesterday", "last Friday", etc. If no date is mentioned, use today's date.
Infer the transaction type ('income' or 'expense'). Words like "paid", "spent", "bought" imply expense. Words like "received", "earned", "got paid", "sold" imply income.

Here are the user's existing categories, items, clients, and vendors. Match the transaction to these if possible.

- If the user mentions an 'order', 'shipping', or 'delivery', you MUST set 'type' to 'income' and 'orderStatus' to 'pending'.
- Extract any 'tracking number' provided.
- Any special instructions for delivery should be put in 'shippingNotes'.

- If you find a close match for the transaction's subject in the Items list, use its name for the 'name' field.
- If the transaction's subject (e.g., "cupcakes", "consulting services") is NOT in the Items list, use the new subject for the 'name' field. The app will create it.

- If you find a matching client/vendor in the lists, use their ID for 'clientId' or 'vendorId'.
- If the user mentions a client/vendor name that is NOT in the provided lists, return the new name in 'newClientName' or 'newVendorName'. DO NOT use 'clientId' or 'vendorId' for new contacts.

Categories: ${JSON.stringify(categories.map(c => ({ name: c.name, type: c.type })))}
Items: ${JSON.stringify(items.map(i => ({ name: i.name, type: i.type, nature: i.nature, unitPrice: i.unitPrice })))}
Clients: ${JSON.stringify(clients.map(c => ({ id: c.id, name: c.name })))}
Vendors: ${JSON.stringify(vendors.map(v => ({ id: v.id, name: v.name })))}

Output a single JSON object with the following structure. All fields are optional.

type PartialTransaction = {
  type?: 'income' | 'expense';
  name?: string; // The primary name of the transaction. Can be a new or existing item.
  description?: string; // Any extra detail.
  amount?: number;
  date?: string; // In YYYY-MM-DD ISO format.
  category?: string; // The name of the category, matched from the categories list.
  clientId?: string; // The ID of an EXISTING client if mentioned.
  vendorId?: string; // The ID of an EXISTING vendor if mentioned.
  newClientName?: string; // The name of a NEW client if mentioned.
  newVendorName?: string; // The name of a NEW vendor if mentioned.
  nature?: 'service' | 'product';
  quantity?: number;
  unitPrice?: number;
  orderStatus?: 'pending' | 'in_progress' | 'ready_for_pickup' | 'shipped' | 'completed' | 'cancelled';
  fulfillmentType?: 'in-house' | 'outsourced';
  deliveryMethod?: 'pickup' | 'delivery' | 'digital' | 'shipping';
  trackingNumber?: string;
  shippingNotes?: string;
}`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: `Parse this transaction: "${text}"`,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: 'application/json',
                temperature: 0,
            },
        });

        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
            jsonStr = match[2].trim();
        }

        const parsedData = JSON.parse(jsonStr);

        // Basic validation
        if (typeof parsedData === 'object' && parsedData !== null) {
            return parsedData as PartialTransaction;
        }

        console.warn("Gemini returned non-object data:", parsedData);
        return null;

    } catch (error) {
        console.error("Error parsing transaction from Gemini:", error);
        return null;
    }
};

export const parseDocumentFromText = async (
  text: string, 
  clients: Client[]
): Promise<{ clientName?: string, items?: QuotationItem[] } | null> => {
    const systemInstruction = `You are an intelligent document creation assistant. Your task is to parse a user's natural language input and convert it into a structured JSON object representing an invoice or quotation.

The user is a small business owner. The language might be informal.
Today's date is ${new Date().toISOString()}.

Here is the user's existing client list. Match the transaction to these if possible.

- If the user mentions a client name that is in the provided list, use their name.
- If the user mentions a client name that is NOT in the provided list, use the new name.

Clients: ${JSON.stringify(clients.map(c => ({ id: c.id, name: c.name })))}

The user will describe the items, quantities, and prices. Extract these into a list of line items.

Example Input: "Create an invoice for Innovate Corp for 2 website designs at 500 each and 1 logo design for 200."
Example Output: 
{
  "clientName": "Innovate Corp",
  "items": [
    { "name": "Website Design", "quantity": 2, "unitPrice": 500, "description": "Website Design" },
    { "name": "Logo Design", "quantity": 1, "unitPrice": 200, "description": "Logo Design" }
  ]
}

Output a single JSON object with the following structure. All fields are optional.

{
  "clientName"?: string,
  "items"?: { "name": string, "quantity": number, "unitPrice": number, "description"?: string }[]
}`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: `Parse this document request: "${text}"`,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: 'application/json',
                temperature: 0,
            },
        });

        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
            jsonStr = match[2].trim();
        }
        
        const parsedData = JSON.parse(jsonStr);

        // Basic validation
        if (typeof parsedData === 'object' && parsedData !== null) {
            return parsedData as { clientName?: string, items?: QuotationItem[] };
        }

        console.warn("Gemini returned non-object data for document parsing:", parsedData);
        return null;

    } catch (error) {
        console.error("Error parsing document from Gemini:", error);
        return null;
    }
};

export const parseBusinessFromText = async (text: string): Promise<Partial<Business> | null> => {
    const systemInstruction = `You are an intelligent business setup assistant. Your task is to parse a user's natural language input and convert it into a structured JSON object representing a business profile.
    
The user is a small business owner. The language might be informal.
Extract details like the business name, contact information (email, phone, address, website), currency, default tax rate (as a number), payment terms in days (as a number), and any default notes for invoices.

- For currency, if a common symbol is given (e.g., $, £, €, GH₵), use the symbol. If a currency code is given (e.g., GHS, USD), use the appropriate symbol. If no currency is mentioned, do not include the currency field.
- For tax rate and payment terms, extract only the number. E.g., "15% tax" should be 15. "Net 30" should be 30.

Output a single JSON object with the following structure. All fields are optional.

type PartialBusiness = {
  name?: string;
  email?: string;
  phone?: string;
  address?: string;
  website?: string;
  currency?: string;
  taxRate?: number;
  paymentTerms?: number;
  invoiceNotes?: string;
}`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: `Parse this business description: "${text}"`,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: 'application/json',
                temperature: 0,
            },
        });

        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
            jsonStr = match[2].trim();
        }
        
        const parsedData = JSON.parse(jsonStr);

        if (typeof parsedData === 'object' && parsedData !== null) {
            return parsedData as Partial<Business>;
        }

        console.warn("Gemini returned non-object data for business parsing:", parsedData);
        return null;

    } catch (error) {
        console.error("Error parsing business from Gemini:", error);
        return null;
    }
};