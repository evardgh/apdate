
import React from 'react';
import { Transaction } from '../types';

interface StatusBadgeProps {
  status: Transaction['status'] | 'draft' | 'sent' | 'accepted' | 'declined';
  large?: boolean;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status, large = false }) => {
  const baseClasses = `font-semibold rounded-full capitalize ${large ? 'px-3 py-1 text-sm' : 'px-2 py-0.5 text-xs'}`;
  
  let colorClasses = '';
  switch (status) {
    case 'paid':
    case 'accepted':
      colorClasses = 'bg-light-income-bg text-light-income-fg dark:bg-dark-income-bg dark:text-dark-income-fg';
      break;
    case 'unpaid':
      colorClasses = 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300';
      break;
    case 'partially_paid':
      colorClasses = 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      break;
    case 'overdue':
    case 'declined':
      colorClasses = 'bg-light-expense-bg text-light-expense-fg dark:bg-dark-expense-bg dark:text-dark-expense-fg';
      break;
    case 'voided':
    case 'draft':
      colorClasses = 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
      break;
    case 'sent':
        colorClasses = 'bg-sky-100 text-sky-800 dark:bg-sky-900 dark:text-sky-300';
        break;
    default:
      colorClasses = 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
  }

  return (
    <span className={`${baseClasses} ${colorClasses}`}>
      {status.replace('_', ' ')}
    </span>
  );
};

export default StatusBadge;
