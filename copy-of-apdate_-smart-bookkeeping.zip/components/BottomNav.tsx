
import React from 'react';
import { DashboardIcon } from './icons/DashboardIcon';
import { ListIcon } from './icons/ListIcon';
import { PlusIcon } from './icons/PlusIcon';
import { SparklesIcon } from './icons/SparklesIcon';
import { MoreIcon } from './icons/MoreIcon';
import { View } from '../types';

interface BottomNavProps {
  currentView: View;
  setCurrentView: (view: View) => void;
  onAddClick: () => void;
}

const NavItem: React.FC<{
    label: string;
    icon: React.ReactNode;
    isActive: boolean;
    onClick: () => void;
}> = ({ label, icon, isActive, onClick }) => (
    <button onClick={onClick} className={`flex flex-col items-center justify-center w-full transition-colors duration-200 ${isActive ? 'text-accent' : 'text-light-fg-subtle dark:text-dark-fg-subtle hover:text-light-fg-default dark:hover:text-dark-fg-default'}`}>
        {icon}
        <span className="text-xs font-medium">{label}</span>
    </button>
);

const BottomNav: React.FC<BottomNavProps> = ({ currentView, setCurrentView, onAddClick }) => {
    const isMoreSectionActive = ['more', 'profile', 'settings', 'insights', 'documents', 'orders'].includes(currentView);
    
    return (
        <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto h-20 bg-light-bg-subtle/80 dark:bg-dark-bg-subtle/80 backdrop-blur-xl border-t border-light-border-default/50 dark:border-dark-border-default/50 z-30">
            <div className="flex items-center justify-around h-full pt-2 pb-6">
                <NavItem
                    label="Dashboard"
                    icon={<DashboardIcon />}
                    isActive={currentView === 'dashboard'}
                    onClick={() => setCurrentView('dashboard')}
                />
                <NavItem
                    label="Transactions"
                    icon={<ListIcon />}
                    isActive={currentView === 'transactions'}
                    onClick={() => setCurrentView('transactions')}
                />
                <button 
                    onClick={onAddClick}
                    className="w-16 h-16 -mt-10 bg-accent rounded-full flex items-center justify-center text-accent-fg shadow-lg shadow-blue-500/30 hover:bg-opacity-90 transition-all transform hover:scale-105"
                    aria-label="Add Transaction"
                >
                    <PlusIcon />
                </button>
                <NavItem
                    label="Apdate AI"
                    icon={<SparklesIcon />}
                    isActive={currentView === 'ai'}
                    onClick={() => setCurrentView('ai')}
                />
                <NavItem
                    label="More"
                    icon={<MoreIcon />}
                    isActive={isMoreSectionActive}
                    onClick={() => setCurrentView('more')}
                />
            </div>
        </div>
    );
};

export default BottomNav;
