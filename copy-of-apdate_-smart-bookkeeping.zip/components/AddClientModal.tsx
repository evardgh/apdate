import React, { useState, useEffect } from 'react';
import { Client } from '../types';
import { CloseIcon } from './icons/CloseIcon';

interface AddClientModalProps {
  onClose: () => void;
  onAddClient?: (client: Omit<Client, 'id'>) => void;
  onUpdateClient?: (client: Client) => void;
  clientToEdit?: Client | null;
}

const AddClientModal: React.FC<AddClientModalProps> = ({ onClose, onAddClient, onUpdateClient, clientToEdit }) => {
  const isEditMode = !!clientToEdit;
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  useEffect(() => {
    if (isEditMode) {
      setName(clientToEdit.name);
      setEmail(clientToEdit.email || '');
      setPhone(clientToEdit.phone || '');
    }
  }, [clientToEdit, isEditMode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
        alert("Client name is required.");
        return;
    }
    if (isEditMode) {
        onUpdateClient?.({ ...clientToEdit, name, email, phone });
    } else {
        onAddClient?.({ name, email, phone });
    }
    onClose();
  };
  
  const commonInputClasses = "w-full bg-light-bg-inset dark:bg-dark-bg-inset border-transparent focus:border-accent border-2 rounded-xl py-3 px-4 focus:outline-none focus:ring-0 text-light-fg-default dark:text-dark-fg-default placeholder:text-light-fg-subtle placeholder:dark:text-dark-fg-subtle transition-colors";
  
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in" onClick={onClose}>
      <div 
        className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl shadow-2xl w-full max-w-sm m-4 p-6 relative animate-slide-up border border-light-border-default/50 dark:border-dark-border-default"
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-light-fg-subtle dark:text-dark-fg-subtle hover:text-light-fg-default dark:hover:text-dark-fg-default">
          <CloseIcon />
        </button>
        <h2 className="text-xl font-bold mb-6 text-light-fg-default dark:text-dark-fg-default">
            {isEditMode ? 'Edit Client' : 'Add New Client'}
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <input type="text" placeholder="Client Name" value={name} onChange={e => setName(e.target.value)} className={commonInputClasses} required />
          <input type="email" placeholder="Email (Optional)" value={email} onChange={e => setEmail(e.target.value)} className={commonInputClasses} />
          <input type="tel" placeholder="Phone (Optional)" value={phone} onChange={e => setPhone(e.target.value)} className={commonInputClasses} />
          
          <button type="submit" className="w-full bg-accent text-accent-fg font-bold py-3.5 px-4 rounded-xl hover:opacity-90 transition-opacity">
              {isEditMode ? 'Update Client' : 'Add Client'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddClientModal;