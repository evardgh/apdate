
import React from 'react';
import { View } from '../types';
import { UserIcon } from './icons/UserIcon';
import { ChevronRightIcon } from './icons/ChevronRightIcon';
import { ReportsIcon } from './icons/ReportsIcon';
import { SettingsIcon } from './icons/SettingsIcon';
import { DocumentTextIcon } from './icons/DocumentTextIcon';
import { BusinessIcon } from './icons/BusinessIcon';
import { ClipboardListIcon } from './icons/ClipboardListIcon';

interface MoreViewProps {
  setCurrentView: (view: View) => void;
}

const MoreView: React.FC<MoreViewProps> = ({ setCurrentView }) => {

  const MenuItem: React.FC<{
    label: string;
    icon: React.ReactNode;
    onClick: () => void;
  }> = ({ label, icon, onClick }) => (
    <button onClick={onClick} className="w-full text-left">
      <div className="flex items-center justify-between p-4 bg-light-bg-subtle dark:bg-dark-bg-subtle hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors border-b border-light-border-default dark:border-dark-border-default last:border-b-0">
          <div className="flex items-center gap-4">
              <div className="text-light-fg-subtle dark:text-dark-fg-subtle">{icon}</div>
              <span className="font-medium text-light-fg-default dark:text-dark-fg-default">{label}</span>
          </div>
          <ChevronRightIcon />
      </div>
    </button>
  );

  return (
    <div className="space-y-4">
       <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl overflow-hidden border border-light-border-default dark:border-dark-border-default">
        <MenuItem
            label="Profile & Contacts"
            icon={<UserIcon />}
            onClick={() => setCurrentView('profile')}
        />
         <MenuItem
            label="Businesses"
            icon={<BusinessIcon />}
            onClick={() => setCurrentView('businesses')}
        />
         <MenuItem
            label="Insights"
            icon={<ReportsIcon />}
            onClick={() => setCurrentView('insights')}
        />
         <MenuItem
            label="Invoices & Quotes"
            icon={<DocumentTextIcon />}
            onClick={() => setCurrentView('documents')}
        />
        <MenuItem
            label="Order Tracker"
            icon={<ClipboardListIcon />}
            onClick={() => setCurrentView('orders')}
        />
        <MenuItem
            label="Settings"
            icon={<SettingsIcon />}
            onClick={() => setCurrentView('settings')}
        />
       </div>
    </div>
  );
};

export default MoreView;
